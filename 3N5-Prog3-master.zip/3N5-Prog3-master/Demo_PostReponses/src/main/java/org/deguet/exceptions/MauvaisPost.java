package org.deguet.exceptions;

/**
 * Created by joris on 16-11-15.
 */
public class MauvaisPost extends Exception {
}
