package org.deguet.modele;

/**
 * Created by joris on 16-11-15.
 */
public class ElementContenu {

    public String contenu;
}
