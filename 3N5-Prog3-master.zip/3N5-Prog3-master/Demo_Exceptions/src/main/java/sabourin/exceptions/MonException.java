package sabourin.exceptions;

public class MonException extends Exception{
    public MonException(String errorMessage) {
        super(errorMessage);
    }
}
