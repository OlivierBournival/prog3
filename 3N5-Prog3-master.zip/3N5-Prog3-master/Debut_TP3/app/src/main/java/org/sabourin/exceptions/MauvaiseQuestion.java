package org.sabourin.exceptions;

public class MauvaiseQuestion extends Exception {
    public MauvaiseQuestion(String message) {
        super(message);
    }
}
