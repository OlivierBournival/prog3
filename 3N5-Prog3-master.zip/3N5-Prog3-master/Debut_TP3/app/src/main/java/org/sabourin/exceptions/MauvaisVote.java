package org.sabourin.exceptions;

public class MauvaisVote extends Exception {
    public MauvaisVote(String message) {
        super(message);
    }
}
