package org.nomfamille.exo1;

public class Imperatif {


   /* -------------- MODIFIEZ UNIQUEMENT LE CODE, PAS LES TESTS -------------*/
   public static void main(String[] args) {
   /* rectangle(3,3); */
    premiersEntiers(5);
   }

    public static String rectangle(int hauteur, int largeur){
       String rectangle1  = "";
       for (int num =0 ; num<= largeur ; num++ ){

            rectangle1 = rectangle1+"#";
        }
        rectangle1 = rectangle1+"\n";

        for (int Haut =0 ; Haut<= hauteur-2 ; Haut++ ){
            rectangle1 = rectangle1+"#";
            for (int Larg =0 ; Larg<= largeur-2 ; Larg++ ) {

                rectangle1 = rectangle1+" ";

            }

            rectangle1 = rectangle1+"#\n";
        }
        for (int num =0 ; num<= largeur ; num++ ){
            rectangle1 = rectangle1+"#";
        }
        rectangle1 = rectangle1+"\n";
        return rectangle1;
    }

    public static Integer premiersEntiers(int max){
        Integer f = 1;
        if (max<=0) throw new IllegalArgumentException();
        for (int num =1 ; num<= max ; num++ ){
            f = f*num ;
            System.out.print(num + " ");
        }


        return f;

    }


}
