package org.nomfamille.exo2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LibStandard {


    /* -------------- MODIFIEZ UNIQUEMENT LE CODE, PAS LES TESTS -------------*/


    public static List<Integer> nFoisN(int max) {
        List<Integer> th= new ArrayList<>();
        for (int num =1 ; num<= max ; num++ ){
            for (int e =1 ; e<= num ; e++ ){
                th.add(num);

            }
        }
        System.out.print(th);
        return th ;
    }

    public static List<Integer> triCroissant(List<Integer> source) {

        Collections.sort(source);
        return source;
    }

}
