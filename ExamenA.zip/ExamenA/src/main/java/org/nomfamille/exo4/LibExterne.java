package org.nomfamille.exo4;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;


import java.io.File;
import java.io.IOException;
import java.util.List;

import static javax.management.Query.attr;

public class LibExterne {


    /* -------------- PAS DE TESTS -------------*/


    public static void main(String[] args) throws IOException {

        String link ="https://departement-info-cem.github.io/3N5-Prog3/testbot/index.html";

            Document doc =  Jsoup.connect("https://departement-info-cem.github.io/3N5-Prog3/testbot/index.html").get();
            String html = String.valueOf(doc.select("li"));
            System.out.print(html);

    }
}
