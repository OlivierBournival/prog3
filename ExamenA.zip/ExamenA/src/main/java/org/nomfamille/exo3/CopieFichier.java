package org.nomfamille.exo3;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.ParseException;

public class CopieFichier {


    /* -------------- PAS DE TESTS -------------*/


    public static void main(String[] args) throws Exception {
        if (args[0]==null) {throw new  Exception() ;}else {


            System.out.println(args[0]);
        }
        FileReader reader = new FileReader(args[0]);
        String f = String.valueOf(reader.read());
        reader.close();
        System.out.println(f);

        File makeFileCourrielle = new File("OlivierBournival.txt ");
        makeFileCourrielle.mkdirs();
        FileWriter Writer = new FileWriter("resultat/courriels.txt");
        Writer.write("Olivier.Bournival");
        Writer.close();

    }

}
