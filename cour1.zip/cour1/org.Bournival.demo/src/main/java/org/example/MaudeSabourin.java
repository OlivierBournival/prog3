package org.example;

public class MaudeSabourin {    public static void main( String[] args )
{

    System.out.println( "Salut  Maude Sabourin" );

}
}
