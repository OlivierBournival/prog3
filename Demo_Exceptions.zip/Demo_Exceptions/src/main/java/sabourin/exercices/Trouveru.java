package sabourin.exercices;

import sabourin.exceptions.MonException;

import java.util.ArrayList;
import java.util.Optional;

public class Trouveru {

    public static void main( String[] args ) throws MonException {


        ArrayList<String> f = new ArrayList<>();
        f.add("ijiohjj");
        f.add("jtj");
        f.add("jtyij");f.add("oli");f.add("jj");f.add("nojj");f.add("jjcf");f.add("joj");f.add("cycjj");


        System.out.println(Trouve(f,"oli"));



    }

    public static Integer Trouve (ArrayList<String> v , String élémentChercher) throws MonException {

        int b =0;
        for (String tryy : v) {
            if (tryy.equals(élémentChercher)) {
                b++;
                Integer intObj = new Integer(b);
                return intObj;
            }
            
        }
        throw new MonException("Pas Trouver");

        
    }


}
