package org.example;

import java.io.File;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        try {

            // Recevoir le fichier
            File f = new File("vide.txt");
            File fgnb = new File("..\\vidjhjhe.txt");
            fgnb.createNewFile();
            // Créer un nouveau fichier
            // Vérifier s'il n'exyjytytytyiste pas
            if (f.createNewFile())
                System.out.println("File created");
            else
                System.out.println("File already exists");
        }
        catch (Exception e) {
            System.err.println(e);
        }
    }
}
