package org.example;

import com.sun.xml.internal.ws.util.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.Stack;

/**
 * Hello world!
 *
 */
public class TrouvePisCompte
{
    public static void main( String[] args )
    {

        List<Integer> liste = new Stack<Integer>(){{ add(10);add(204634);add(10);add(24340);add(10);add(20); }};
        System.out.println(trouve(10,liste));
        System.out.println(compte(10,liste));

    }
    static boolean trouve(int element, List<Integer> liste)
    {

        if (liste.contains(element)){
            return true;
        }
        return false;
    }
    static int compte(int element, List<Integer> liste)
    {
        int count = Collections.frequency(liste, element);

            return count;
    }
}
