package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class LitFichier
{
    public static void main( String[] args ) throws FileNotFoundException {


            // Recevoir le fichier
            File ar0 = new File("LitFichier\\"+args[0] +  ".txt");
            Scanner obj = new Scanner(ar0);
        while (obj.hasNextLine()) {
            System.out.println(obj.nextLine());
        }
        System.out.println("----------------");
        // Recevoir le fichier
        File ar1 = new File("LitFichier\\"+args[1] +  ".txt");
        Scanner obj1 = new Scanner(ar1);
        while (obj1.hasNextLine()) {
            System.out.println(obj1.nextLine());
        }
        System.out.println("----------------");
        // Recevoir le fichier
        File ar2 = new File("LitFichier\\"+args[2] +  ".txt");
        Scanner obj2 = new Scanner(ar2);
        while (obj2.hasNextLine()) {
            System.out.println(obj2.nextLine());
        }
        System.out.println("----------------");


    }

}
