package org.example;

import java.io.File;

/**
 * Hello world!
 *
 */
public class ListeSimple
{
    public static void main( String[] args )
    {
        repete(4,2);

    }
    static void repete(int n, int nombreFois) {
        int nb = 1;
        System.out.print("[");
        for (int i = 0; i < n; i++){

            for (int y = 0; y < nombreFois; y++){
                System.out.print(nb);
                if (y < nombreFois-1 || nb < n) {
                    System.out.print(", ");
                }

            }
            nb++;
        }
        System.out.print("]");
    }
}
