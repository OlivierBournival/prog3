package org.example;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class EntrezUnNombre
{
    public static void main( String[] args )
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("entrer un Nombre");
        while (scan.hasNext()  && !scan.hasNextInt()) {
            System.out.println("entrer un Nombre");
            scan.next();
        }
        System.out.println("merci votre nb est "+ scan.nextLine());

    }
}
