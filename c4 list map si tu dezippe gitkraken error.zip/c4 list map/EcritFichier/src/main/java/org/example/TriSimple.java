package org.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Hello world!
 *
 */
public class TriSimple
{
    public static void main( String[] args )
    {
        List<String>  num = Arrays.asList("[0.1, 12.34, -0.1234, 3.1416]".replace("[", "").replace("]", "").split(", "));
        List<Double> listOfDouble = convertStringListTodoubleList( num ,Double::parseDouble);
        Collections.sort(listOfDouble);
        Collections.reverse(listOfDouble);
        tri(listOfDouble);
    }
    static void tri(List<Double> liste) {

        System.out.print("[");
        for (int i = liste.size()-1; i >= 0; i--){
            System.out.print(liste.get(i)+", ");


        }
        System.out.print("]");
    }
    public static <T, U> List<U> convertStringListTodoubleList(List<T> listOfString, Function<T, U> function)
    {
        return (List<U>) listOfString.stream()
                .map(function)
                .collect(Collectors.toList());
    }
}
