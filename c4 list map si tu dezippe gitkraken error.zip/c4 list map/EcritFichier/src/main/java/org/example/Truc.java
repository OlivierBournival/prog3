package org.example;

public class Truc {
    public int pipo ;
    public String popi ;

    @Override
    public String toString() {
        return "Truc{" +
                "pipo=" + pipo +
                ", popi='" + popi + '\'' +
                '}';
    }
}

