package org.example;


import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class Listetréférences
{
    public static void main( String[] args )
    {
        Truc a = new Truc();
        a.pipo = 1;
        a.popi = "A";
        Truc b = new Truc();
        b.pipo = 2;
        b.popi = "B";
        Truc c = new Truc();
        c.pipo = 3;
        c.popi = "F";
        List<Truc> liste1 = new ArrayList<Truc>();
        liste1.add(a);
        liste1.add(b);
        liste1.add(c);
        List<Truc> liste2 = new ArrayList<Truc>();
        liste2.add(b);
        liste2.add(c);
        liste2.add(a);
        a.pipo = 11;
        a.popi = "Amodifier";
        System.out.println(liste1);
        System.out.println(liste2);





    }
}
