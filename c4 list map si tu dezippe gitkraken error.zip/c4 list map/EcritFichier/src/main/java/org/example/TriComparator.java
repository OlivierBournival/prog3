package org.example;

import java.io.File;

/**
 * Hello world!
 *
 */
public class TriComparator
{
    public static void main( String[] args )
    {

                System.out.println("no way jose");

    }
}
