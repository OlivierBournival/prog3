package org.example;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.Integer;
import java.net.*;
import java.io.*;
import java.util.Random;
import com.google.gson.Gson;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException {

        persone per = new persone();
        Gson gson = new Gson();
        String json =  gson.toJson(per);

        System.out.println( json);

        persone obj2 = gson.fromJson(json, persone.class);
        System.out.println( obj2.toString());
        /*
        int bob = 0 ;
        for (int e = (Integer.parseInt(args[0])) +1  ; e>0 ; e-- )
        {
            System.out.print(" ");
        }
        System.out.println("*");
        for (int num =Integer.parseInt(args[0]) ; num>0 ; num-- )
        {
            bob++;
            for (int e = num  ; e>0 ; e-- )
            {
                System.out.print(" ");
            }
                    for (int i =0 ; i<=Integer.parseInt(args[0])-num+bob+1 ; i++ )
                    {
                        System.out.print("*");
                    }
                System.out.println("");
        }

         */
        System.out.println( obj2.toString());
        /* fgfdhfghfghfghgf */
        Random random = new Random();
        List<Integer> table = new ArrayList<Integer>();
        for (int e = 99  ; e>0 ; e-- )
        {
            table.add(random.nextInt());
        }

        System.out.println("site" );

        URL oracle = new URL("http://www.perdu.com/");
        URLConnection yc = oracle.openConnection();
        BufferedReader in = new BufferedReader(new InputStreamReader(
                yc.getInputStream()));
        String inputLine;
        while ((inputLine = in.readLine()) != null)
            System.out.println(inputLine);
        in.close();
        /*
        char[] str = args[0].toCharArray();
        System.out.println(str);

         */

        int bob= Integer.parseInt(args[0]);
        String bi = Integer.toBinaryString(bob) ;
        System.out.println(bi);

        float flo = bob;
        System.out.println(flo);

        double dou = Double.parseDouble(args[1]);
        System.out.println(dou);
        /*
        int errr = Integer.parseInt(args[3]);
        System.out.println(errr);

         */







    }
}
