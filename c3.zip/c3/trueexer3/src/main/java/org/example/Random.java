package org.example;

public class Random {
}
