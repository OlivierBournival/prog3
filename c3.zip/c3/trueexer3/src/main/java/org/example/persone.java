package org.example;

public class persone {

    public String nom = "oli";
    public  int num = 5000;

    @Override
    public String toString() {
        return "persone{" +
                "nom='" + nom + '\'' +
                '}';
    }
}
